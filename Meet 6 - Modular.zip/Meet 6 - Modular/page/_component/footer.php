<section class="container">
    <div>
        <small>
            <p class="text-center">© 2021</p>
        </small>
    </div>
</section>
<script src="../src/js/bootstrap.bundle.jss"></script>
</body>

</html>