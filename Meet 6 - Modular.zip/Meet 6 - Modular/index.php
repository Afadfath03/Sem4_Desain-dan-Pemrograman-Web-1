<?php

header("Location: page/page.php?mod=home");

?>